Test values:
1) Epsilon=0.3, MinPoints=10
2) Epsilon=0.5, MinPoints=5
3) Epsilon=0., MinPoints=10

Did not have enough time to turn the DB scan into a callable function taking parameters, but its working is visible in the main file.
Was not able to add outliers manually.
No visualization or colors were added.
Two CSV files are created. One with the initial generated data, and the 2nd with the data points categorized as core, border, or outlier.

Instructions for running code:
-Find variables Epsilon and MinPoints, change them to what you want, and execute. It should run ok.